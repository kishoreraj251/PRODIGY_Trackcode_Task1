// Get the navigation bar
const navbar = document.getElementById('navbar');

// Add a scroll event listener
window.addEventListener('scroll', () => {
    if (window.scrollY > 50) {
        navbar.style.backgroundColor = '#222'; // Darker color when scrolled
    } else {
        navbar.style.backgroundColor = '#333'; // Original color
    }
});